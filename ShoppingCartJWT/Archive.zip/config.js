module.exports = {
    secret: "supersecret",
};
