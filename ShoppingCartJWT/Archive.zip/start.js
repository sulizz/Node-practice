//for es6
require("@babel/register")({});

module.exports = require("./app");
